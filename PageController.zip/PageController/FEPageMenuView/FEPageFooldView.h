//
//  FEPageProgressView.h
//
//
//  Created by ios on 15/11/9.
//

#import "FEPageProgressView.h"

@interface FEPageFooldView : FEPageProgressView
@property (nonatomic, assign)   BOOL hollow;
@end
